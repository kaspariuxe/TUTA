﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ND
{
    class Program
    {
        IWebDriver driver;
        static void Main(string[] args)
        {
        }
        [SetUp]
        public void StartBrowser()
        {
            driver = new ChromeDriver("D:\\Mokslai\\Tuta\\8 paskaita\\");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }
        string username = "dalia.brunziene@gmail.com";
        string password = "labas123";
        string search = "dress";
        public void Login(string user, string pass)
        {
            driver.Url = "http://automationpractice.com";
            driver.FindElement(By.XPath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).Click();
            driver.FindElement(By.XPath("//*[@id='email']")).SendKeys(user);
            driver.FindElement(By.XPath("//*[@id='passwd']")).SendKeys(pass);
            driver.FindElement(By.XPath("//*[@id='SubmitLogin']/span")).Click();
        }

        public void SearchItem(string choise)
        {
            driver.FindElement(By.XPath("//*[@id='search_query_top']")).SendKeys(choise);
            driver.FindElement(By.XPath("//*[@id='searchbox']/button")).Click();
        }

        public void BuyItem()
        {
            driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[2]/div/div[2]/div[2]/a[1]/span")).Click();
            driver.FindElement(By.XPath("//*[@id='layer_cart']/div[1]/div[2]/div[4]/a/span")).Click();
            driver.FindElement(By.XPath("//*[@id='center_column']/p[2]/a[1]/span")).Click();
            driver.FindElement(By.XPath("//*[@id='center_column']/form/p/button/span")).Click();
            driver.FindElement(By.XPath("//*[@id='cgv']")).Click();
            driver.FindElement(By.XPath("//*[@id='form']/p/button/span")).Click();
            driver.FindElement(By.XPath("//*[@id='HOOK_PAYMENT']/div[2]/div/p/a")).Click();
            driver.FindElement(By.XPath("//*[@id='cart_navigation']/button/span")).Click();

        }


        [Test]

        public void SignInWithCorrectUsernameAndCorrectPassword()
        {
            Login(username, password);
            Assert.True(driver.FindElement(By.XPath("//*[@id='center_column']/h1")).Text.ToLower().Contains("my account"));
        }

        [Test]

        public void SearchForAnItem()
        {
            Login(username, password);
            SearchItem(search);
            Assert.True(driver.FindElement(By.XPath("//*[@id='center_column']/ul/li[2]/div/div[2]/h5/a")).Text.ToLower().Contains("dress"));
        }

        [Test]

        public void FinishBuyingTheItem()
        {
            Login(username, password);
            SearchItem(search);
            BuyItem();
            Assert.True(driver.FindElement(By.XPath("//*[@id='center_column']/p[1]")).Text.ToLower().Contains("complete"));
        }
    }
}
